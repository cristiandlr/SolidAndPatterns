package org.formacion.template;

public class InscripcionLucha extends InscripcionTorneo {

	public InscripcionLucha(Polideportivo polideportivo) {
		super(polideportivo, "torneo lucha");
	}
	
	@Override
	protected boolean puedeApuntarse (Solicitud solicitud) {
		// menores de 15 no pueden apuntarse
		boolean edad = solicitud.getEdat() > 14;
		
		// peso minimo, 60 kilos
		boolean peso = solicitud.getPeso() > 59;
		
		return edad && peso;
	}
	
	@Override
	protected boolean maximoPartipantes() {
		
		if (torneo.getAceptadas().size() >= 6) {
			// solo pueden participar 6 personas
			return false;
		}
		
		return true;
	}
	
	@Override
	protected void cierraTorneo() {
		if (torneo.getAceptadas().size() == 6) {
			// plazas llenas -> reservamos polideportivo
			// El tiempo estimado del torneo son 4 horas
			polideportivo.reserva(torneo, 4);
		}
	}

}
