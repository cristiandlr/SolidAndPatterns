package org.formacion.template;

public class InscripcionTenis extends InscripcionTorneo {
	
	public InscripcionTenis(Polideportivo polideportivo) {
		super(polideportivo, "torneo tenis");
	}

	@Override
	protected boolean puedeApuntarse (Solicitud solicitud) {
		// menores de 10 no pueden apuntarse
		boolean edad = solicitud.getEdat() > 9;
		
		return edad;
	}
	
	@Override
	protected boolean maximoPartipantes() {
		if (torneo.getAceptadas().size() >= 4) {
			// solo pueden participar 4 personas
			return false;
		}
		
		return true;
	}
	
	@Override
	protected void cierraTorneo() {
		if (torneo.getAceptadas().size() == 4) {
			// plazas llenas -> reservamos polideportivo
			// El tiempo estimado del torneo son 8 horas
			polideportivo.reserva(torneo, 8);
		}
	}
	
}
