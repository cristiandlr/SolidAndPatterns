package org.formacion.template;

public abstract class InscripcionTorneo {
	protected final Torneo torneo;
	protected final Polideportivo polideportivo;
	
	public InscripcionTorneo(Polideportivo polideportivo, String nombreTorneo) {
		this.polideportivo = polideportivo;
		this.torneo = new Torneo(nombreTorneo);
	}
	
	public Torneo getTorneo() {
		return torneo;
	}
	
	public boolean apunta (Solicitud solicitud) {
		
		if (!puedeApuntarse(solicitud)) return false;
		
		if (!maximoPartipantes()) return false;
		
		torneo.apunta(solicitud);
		
		cierraTorneo();

		return true;
	}
	
	protected abstract boolean puedeApuntarse (Solicitud solicitud);
	
	protected abstract boolean maximoPartipantes();
	
	protected abstract void cierraTorneo();
}
