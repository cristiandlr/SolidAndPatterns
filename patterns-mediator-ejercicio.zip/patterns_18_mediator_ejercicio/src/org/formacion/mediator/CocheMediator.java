package org.formacion.mediator;

public class CocheMediator {
	
	private Coche coche;
	private Radio radio;
	private Telefono telefono;
	
	public CocheMediator(Coche coche, Radio radio, Telefono telefono) {
		coche.setMediator(this);
		radio.setMediator(this);
		telefono.setMediator(this);
		this.coche = coche;
		this.radio = radio;
		this.telefono = telefono;
	}
	
	public void encenderCoche() {
		radio.enciende();
		telefono.apagaMusica();
	}
    
	public void sonarTelefono() {
		radio.apaga();
	}
	
	public void encenderRadio() {
		telefono.apagaMusica();
	}
	
	public void recibeLlamada() {
		radio.apaga();
	}
	
	public void apagarCoche() {
		//radio.apaga();
	}
	
	public void apagarRadio() {
		radio.apaga();
	}
	
	public Coche getCoche() {
		return coche;
	}
	
	public Radio getRadio() {
		return radio;
	}
	
	public Telefono getTelefono() {
		return telefono;
	}
}
