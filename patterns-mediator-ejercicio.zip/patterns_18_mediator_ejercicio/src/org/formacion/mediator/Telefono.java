package org.formacion.mediator;

public class Telefono {

	private boolean musicaOn = false;
	private CocheMediator mediator;
	
	public void setMediator(CocheMediator mediator) {
		this.mediator = mediator;
	}
	
	public void recibeLlamada() {
		mediator.recibeLlamada();
	}

	public void enciendeMusica() {
		musicaOn = true;
	}
	
	public void apagaMusica() {
		musicaOn = false;
	}
	
	public boolean musicaEncendida() {
		return musicaOn;
	}
}
