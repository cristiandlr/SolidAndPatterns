package org.formacion.mediator;

public class Radio {
	
	private boolean encendida = false;
	private CocheMediator mediator;
	
	public void setMediator(CocheMediator mediator) {
		this.mediator = mediator;
	}
	
	public void enciende() {
		mediator.encenderRadio();
		encendida = true; 
	}
	
	public void apaga() {
		encendida = false;
	}
	
	public boolean encendida() {
		return encendida;
	}
}
